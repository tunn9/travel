<?php
/*
Module Icon: <i class="fa fa-tag"></i>
Module Name: ivisa
Module Display Name: IVisa
Admin Menu: <li><a href="%baseurl%admin/ivisa/settings/"><span class="fa fa-tag"></span> Ivisa </a></li>
Integration: Yes
Version: 1.0
*/
